// script.js
document.getElementById('search').addEventListener('input', function (e) {
  const keyword = e.target.value.toLowerCase();
  const projects = document.querySelectorAll('.project');
  
  projects.forEach(project => {
    const text = project.textContent.toLowerCase();
    if (text.includes(keyword)) {
      project.style.display = 'block';
    } else {
      project.style.display = 'none';
    }
  });
});
